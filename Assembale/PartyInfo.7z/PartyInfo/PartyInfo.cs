﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ERP
{
    public partial class PartyInfo : Form
    {
        ClsMain SvCls = new ClsMain();
        string qry = "";

        public PartyInfo()
        {
            InitializeComponent();

            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
        }

        private void MsgTimer_Tick(object sender, EventArgs e)
        {
            this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            lblMsg.Text = "Notification...";
            lblMsgIco.Visible = false;
            lblSadIco.Visible = false;
            lblDelIco.Visible = false;
            lblWaitIco.Visible = false;
            lblInfoIco.Visible = true;

            MsgTimer.Enabled = false;
        }

        private void PartyInfo_Load(object sender, EventArgs e)
        {
            string Qry = "Select ComName from PartyInfo order by ComName";
            cboComName.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboComName.DisplayMember = "ComName";
            cboComName.Text = "";

            Qry = "Select PartyCode from PartyInfo order by PartyCode";
            cboPartyCode.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboPartyCode.DisplayMember = "PartyCode";
            cboPartyCode.Text = "";

            Qry = "Select PartyName from PartyInfo order by PartyName";
            cboPartyName.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboPartyName.DisplayMember = "PartyName";
            cboPartyName.Text = "";

            Qry = "Select ProName from PartyInfo order by ProName";
            cboProName.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboProName.DisplayMember = "ProName";
            cboProName.Text = "";

            Qry = "Select Address from PartyInfo order by Address";
            cboAddress.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboAddress.DisplayMember = "Address";
            cboAddress.Text = "";

            Qry = "Select ContactPerson from PartyInfo order by ContactPerson";
            cboConPerson.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboConPerson.DisplayMember = "ContactPerson";
            cboConPerson.Text = "";

            Qry = "Select Uneon from PartyInfo order by Uneon";
            cboUnion.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboUnion.DisplayMember = "Uneon";
            cboUnion.Text = "";

            Qry = "Select PGroup from PartyInfo order by PGroup";
            cboGroup.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboGroup.DisplayMember = "PGroup";
            cboGroup.Text = "";

            Qry = "Select Class from PartyInfo order by Class";
            cboClass.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboClass.DisplayMember = "Class";
            cboClass.Text = "";

            Qry = "Select Zone from PartyInfo order by Zone";
            cboZone.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboZone.DisplayMember = "Zone";
            cboZone.Text = "";

            Qry = "Select DeedNo from PartyInfo order by DeedNo";
            cboDeadNo.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboDeadNo.DisplayMember = "DeedNo";
            cboDeadNo.Text = "";

            Qry = "Select NIDNo from PartyInfo order by NIDNo";
            cboNidNo.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboNidNo.DisplayMember = "NIDNo";
            cboNidNo.Text = "";

            Qry = "Select TradeLicence from PartyInfo order by TradeLicence";
            cboTradeLcNo.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboTradeLcNo.DisplayMember = "TradeLicence";
            cboTradeLcNo.Text = "";

            Qry = "Select Region from PartyInfo order by Region";
            cboRegion.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboRegion.DisplayMember = "Region";
            cboRegion.Text = "";

            Qry = "Select Area from PartyInfo order by Area";
            cboArea.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboArea.DisplayMember = "Area";
            cboArea.Text = "";

            Qry = "Select HeadID from PartyInfo order by HeadID";
            cboAcctHead.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboAcctHead.DisplayMember = "HeadID";
            cboAcctHead.Text = "";

            Qry = "Select Responsibility from PartyInfo order by Responsibility";
            cboResponsibility.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboResponsibility.DisplayMember = "Responsibility";
            cboResponsibility.Text = "";

            Qry = "Select ResMob from PartyInfo order by ResMob";
            cboResMobile.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboResMobile.DisplayMember = "ResMob";
            cboResMobile.Text = "";

            Qry = "Select SubRes from PartyInfo order by SubRes";
            cboSubResponsibility.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboSubResponsibility.DisplayMember = "SubRes";
            cboSubResponsibility.Text = "";

            Qry = "Select MainRes from PartyInfo order by MainRes";
            cboMainResponsibility.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboMainResponsibility.DisplayMember = "MainRes";
            cboMainResponsibility.Text = "";

            btnAddNew.Select();
        }
        private void GridHeading()
        {
            qry = "SELECT AutoNo, PartyCode as ID,PartyName as [Party Name], ProName as[Proprietor],Address,ContactPerson as [Contact Person],Class,Division,Zila,Upazila,Uneon,PGroup as[Party Group],Phone,Email,Region,Zone,Area,DeedNo as[Deed No],TradeLicence as[Trade Licence],NIDNo as[NID],ChequeAmt as[Cheque Amt],Responsibility,ResMob as[Res Mobile],SubRes as[Sub Responsibility],MainRes as[Main Responsibility],HeadID as[Account Head],ComName as[Company] FROM PartyInfo where PartyCode= '" + cboPartyCode.Text.Trim() + "' ORDER BY PartyCode DESC";
            Grid.DataSource = SvCls.GblDataTable(qry);
            Grid.Refresh();

            lblShowTotal.Text = "Total : " + Grid.Rows.Count.ToString();
            Grid.Columns[0].Visible = false;
        }

        private void ShowMessage(string type, string msg)
        {
            if (type == "info")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblDelIco.Visible = false;
                lblWaitIco.Visible = false;
                lblMsgIco.Visible = false;
                lblInfoIco.Visible = true;
                lblMsg.Text = msg;
                this.PanelTop.BackColor = Color.DarkBlue;
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "save")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblDelIco.Visible = false;
                lblInfoIco.Visible = false;
                lblWaitIco.Visible = false;
                lblMsgIco.Visible = true;
                lblMsg.Text = "Save Successfully....!";
                this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(168)))), ((int)(((byte)(73)))));
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "update")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblDelIco.Visible = false;
                lblInfoIco.Visible = false;
                lblWaitIco.Visible = false;
                lblMsgIco.Visible = true;
                lblMsg.Text = "Edit Successfully....!";
                this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(168)))), ((int)(((byte)(73)))));
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "delete")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblInfoIco.Visible = false;
                lblMsgIco.Visible = false;
                lblWaitIco.Visible = false;
                lblDelIco.Visible = true;
                lblMsg.Text = "Delete Successfully....!";
                this.PanelTop.BackColor = Color.OrangeRed;
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "wait")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblInfoIco.Visible = false;
                lblDelIco.Visible = false;
                lblMsgIco.Visible = false;
                lblWaitIco.Visible = true;
                lblMsg.Text = "Please wait, Loading...!";
                this.PanelTop.BackColor = Color.DarkOrange;
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "not found")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblInfoIco.Visible = false;
                lblMsgIco.Visible = false;
                lblDelIco.Visible = false;
                lblWaitIco.Visible = false;
                lblSadIco.Visible = true;
                lblMsg.Text = "Sorry..! No Record Found";
                this.PanelTop.BackColor = Color.OrangeRed;
                lblMsg.ForeColor = Color.White;
            }
        }

        private void label23_Click(object sender, EventArgs e)
        {

        }

        private void comboBox20_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.grpSrc.Size = new System.Drawing.Size(1089, 608);
            this.grpSrc.Location = new System.Drawing.Point(5, 33);
            grpSrc.Visible = true;

            string Qry = "Select ComName from PartyInfo order by ComName";
            cboSrc.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboSrc.DisplayMember = "ComName";
            cboSrc.Text = "";
        }

        private void btnCloseSrc_Click(object sender, EventArgs e)
        {
            grpSrc.Visible = false;
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            try
            {
                SvCls.toGetData("select isnull(max(convert(numeric,PartyCode)),0)+1 as CodeNo from PartyInfo where ComId=1 and isnumeric(PartyCode)=1");
                if (SvCls.GblRdrToGetData.Read())
                {
                    cboPartyCode.Text = SvCls.GblRdrToGetData["CodeNo"].ToString();
                    SvCls.GblCon.Close();
                }

                cboPartyName.Text = "";
                cboProName.Text = "";
                cboAddress.Text = "";
                cboConPerson.Text = "";
                cboClass.Text = "";
                cboDivision.Text = "";
                cboZilla.Text = "";
                cboThana.Text = "";
                cboUnion.Text = "";
                cboGroup.Text = "";
                txtPhone.Text = "";
                txtEmail.Text = "";
                cboRegion.Text = "";
                cboZone.Text = "";
                cboArea.Text = "";
                cboDeadNo.Text = "";
                cboTradeLcNo.Text = "";
                cboNidNo.Text = "";
                txtTotalCheque.Text = "";
                cboResponsibility.Text = "";
                cboResMobile.Text = "";
                cboSubResponsibility.Text = "";
                cboMainResponsibility.Text = "";
                cboAcctHead.Text = "";
                cboComName.Text = "";

                cboComName.Select();
                btnSave.Text = "Save";

                GridHeading();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message.ToString(), "Message", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cboPartyCode.Text = "";
            cboPartyName.Text = "";
            cboProName.Text = "";
            cboAddress.Text = "";
            cboConPerson.Text = "";
            cboClass.Text = "";
            cboDivision.Text = "";
            cboZilla.Text = "";
            cboThana.Text = "";
            cboUnion.Text = "";
            cboGroup.Text = "";
            txtPhone.Text = "";
            txtEmail.Text = "";
            cboRegion.Text = "";
            cboZone.Text = "";
            cboArea.Text = "";
            cboDeadNo.Text = "";
            cboTradeLcNo.Text = "";
            cboNidNo.Text = "";
            txtTotalCheque.Text = "";
            cboResponsibility.Text = "";
            cboResMobile.Text = "";
            cboSubResponsibility.Text = "";
            cboMainResponsibility.Text = "";
            cboAcctHead.Text = "";
            cboComName.Text = "";

            //GridHeading();
        }
        private void btnLoadCombo_Click(object sender, EventArgs e)
        {
            string Qry = "Select PartyCode from PartyInfo order by PartyCode";
            cboPartyCode.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboPartyCode.DisplayMember = "PartyCode";
            cboPartyCode.Text = "";

            ShowMessage("wait", "");
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (cboComName.Text.Trim() == "")
            {
                MessageBox.Show("Company Name Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboComName.Select();
                return;
            }

            if (cboPartyCode.Text.Trim() == "")
            {
                MessageBox.Show("Party Code Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboPartyCode.Select();
                return;
            }
            if (cboPartyName.Text.Trim() == "")
            {
                MessageBox.Show("Party Name Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboPartyName.Select();
                return;
            }

            if (cboProName.Text.Trim() == "")
            {
                MessageBox.Show("Proprietor Name Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboProName.Select();
                return;
            }

            if (cboConPerson.Text.Trim() == "")
            {
                MessageBox.Show("Contact Person Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboConPerson.Select();
                return;
            }

            if (txtPhone.Text.Trim() == "")
            {
                MessageBox.Show("Phone Number Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPhone.Select();
                return;
            }
            if (cboNidNo.Text.Trim() == "")
            {
                MessageBox.Show("NID No Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboNidNo.Select();
                return;
            }
            if (cboTradeLcNo.Text.Trim() == "")
            {
                MessageBox.Show("Trade Licences No Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboTradeLcNo.Select();
                return;
            }
            if (cboAcctHead.Text.Trim() == "")
            {
                MessageBox.Show("Account Head Can't be Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                cboAcctHead.Select();
                return;
            }
            string SaveQry;
            string SelectQry;
            string EdtQry;

            SaveQry = "Insert into PartyInfo (ComId,PartyCode,PartyName,ProName,Address,ContactPerson,Class,Division,Zila,Upazila,Uneon,PGroup,Phone,Email,Region,Zone,Area,DeedNo,TradeLicence,NIDNo,ChequeAmt,Responsibility,ResMob,SubRes,MainRes,HeadID,ComName,PcName,UserCode,UserIP)values" +
                "('1','" + cboPartyCode.Text.Trim() + "','" + cboPartyName.Text.Trim() + "','" + cboProName.Text.Trim() + "','" + cboAddress.Text.Trim() + "','" + cboConPerson.Text.Trim() + "','" + cboClass.Text.Trim() + "','" + cboDivision.Text.Trim() + "','" + cboZilla.Text.Trim() + "','" + cboThana.Text.Trim() + "','" + cboUnion.Text.Trim() + "','" + cboGroup.Text.Trim() + "','" + txtPhone.Text.Trim() + "'," +
                "'" + txtEmail.Text.Trim() + "','" + cboRegion.Text.Trim() + "','" + cboZone.Text.Trim() + "','" + cboArea.Text.Trim() + "','" + cboDeadNo.Text.Trim() + "','" + cboTradeLcNo.Text.Trim() + "','" + cboNidNo.Text.Trim() + "','" + txtTotalCheque.Text.Trim() + "','" + cboResponsibility.Text.Trim() + "','" + cboResMobile.Text.Trim() + "','" + cboSubResponsibility.Text.Trim() + "','" + cboMainResponsibility.Text.Trim() + "','" + cboAcctHead.Text.Trim() + "','" + cboComName.Text.Trim() + "','PPT-PC','SA','192.168.31.101')";

            SelectQry = "Select ComId,PartyName,ProName,Address,ContactPerson,Class,Division,Zila,Upazila,Uneon,PGroup,Phone,Email,Region,Zone,Area,DeedNo,TradeLicence,NIDNo,ChequeAmt,Responsibility,ResMob,SubRes,MainRes,HeadID,ComName,PcName,UserCode,UserIP from PartyInfo where PartyCode='" + cboPartyCode.Text.Trim() + "'";

            EdtQry = "Update PartyInfo set ComId='1',PartyName='" + cboPartyName.Text.Trim() + "',ProName='" + cboProName.Text.Trim() + "',Address='" + cboAddress.Text.Trim() + "',ContactPerson='" + cboConPerson.Text.Trim() + "',Class='" + cboClass.Text.Trim() + "',Division='" + cboDivision.Text.Trim() + "'," +
                "Zila='" + cboZilla.Text.Trim() + "',Upazila='" + cboThana.Text.Trim() + "',Uneon='" + cboUnion.Text.Trim() + "',PGroup='" + cboGroup.Text.Trim() + "',Phone='" + txtPhone.Text.Trim() + "',Email='" + txtEmail.Text.Trim() + "'," +
                "Region='" + cboRegion.Text.Trim() + "',Zone='" + cboZone.Text.Trim() + "',Area='" + cboArea.Text.Trim() + "',DeedNo='" + cboDeadNo.Text.Trim() + "',TradeLicence='" + cboTradeLcNo.Text.Trim() + "',NIDNo='" + cboNidNo.Text.Trim() + "',ChequeAmt='" + txtTotalCheque.Text.Trim() + "'," +
                "Responsibility='" + cboResponsibility.Text.Trim() + "',ResMob='" + cboResMobile.Text.Trim() + "',SubRes='" + cboSubResponsibility.Text.Trim() + "',MainRes='" + cboMainResponsibility.Text.Trim() + "',HeadID='" + cboAcctHead.Text.Trim() + "',ComName='" + cboComName.Text.Trim() + "',PcName='POWER-PC',UserCode='SA',UserIP='192.168.31.103' where PartyCode='" + cboPartyCode.Text.Trim() + "'";

            if (SvCls.DataExist(SelectQry).ToString() == "0")
            {
                SvCls.insertUpdate(SaveQry);
                ShowMessage("save", "");
                btnSave.Text = "Edit";

                GridHeading();
                btnAddNew.Focus();
            }
            else
            {
                SvCls.insertUpdate(EdtQry);
                ShowMessage("update", "");
                GridHeading();
                btnAddNew.Focus();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {

            if (MessageBox.Show("Do you realy want to delete ?", "Powerpoint Technologies.", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {
                SvCls.insertUpdate("Delete from PartyInfo where PartyCode='" + cboPartyCode.Text.Trim() + "' and ComId=1");
                ShowMessage("delete", "");
                GridHeading();
            }
        }

        private void PanelTop_Paint(object sender, PaintEventArgs e)
        {

        }

        private void PanelTop_DoubleClick(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btnLoadGridData_Click(object sender, EventArgs e)
        {
            qry = "SELECT AutoNo, PartyCode as ID,PartyName as [Party Name], ProName as[Proprietor],Address,ContactPerson as [Contact Person],Class,Division,Zila,Upazila,Uneon,PGroup as[Party Group],Phone,Email,Region,Zone,Area,DeedNo as[Deed No],TradeLicence as[Trade Licence],NIDNo as[NID],ChequeAmt as[Cheque Amt],Responsibility,ResMob as[Res Mobile],SubRes as[Sub Responsibility],MainRes as[Main Responsibility],HeadID as[Account Head],ComName as[Company] FROM PartyInfo ORDER BY PartyCode DESC";
            Grid.DataSource = SvCls.GblDataTable(qry);
            Grid.Refresh();

            lblShowTotal.Text = "Total : " + Grid.Rows.Count.ToString();
            Grid.Columns[0].Visible = false;

            ShowMessage("wait", "");
        }

        private void cboPartyCode_Leave(object sender, EventArgs e)
        {
            if (cboPartyCode.Text.Trim() != "")
            {
                SvCls.toGetData("Select PartyName,ProName,Address,ContactPerson,Class,Division,Zila,Upazila,Uneon,PGroup,Phone,Email,Region,Zone,Area,DeedNo,TradeLicence,NIDNo,ChequeAmt,Responsibility,ResMob,SubRes,MainRes,HeadID,ComName from PartyInfo where PartyCode='" + cboPartyCode.Text.Trim() + "' and ComId='1'");
                if (SvCls.GblRdrToGetData.Read())
                {
                    cboPartyName.Text = SvCls.GblRdrToGetData["PartyName"].ToString();
                    cboProName.Text = SvCls.GblRdrToGetData["ProName"].ToString();
                    cboAddress.Text = SvCls.GblRdrToGetData["Address"].ToString();
                    cboConPerson.Text = SvCls.GblRdrToGetData["ContactPerson"].ToString();
                    cboClass.Text = SvCls.GblRdrToGetData["Class"].ToString();
                    cboDivision.Text = SvCls.GblRdrToGetData["Division"].ToString();
                    cboZilla.Text = SvCls.GblRdrToGetData["Zila"].ToString();
                    cboThana.Text = SvCls.GblRdrToGetData["Upazila"].ToString();
                    cboUnion.Text = SvCls.GblRdrToGetData["Uneon"].ToString();
                    cboGroup.Text = SvCls.GblRdrToGetData["PGroup"].ToString();
                    txtPhone.Text = SvCls.GblRdrToGetData["Phone"].ToString();
                    txtEmail.Text = SvCls.GblRdrToGetData["Email"].ToString();
                    cboRegion.Text = SvCls.GblRdrToGetData["Region"].ToString();
                    cboZone.Text = SvCls.GblRdrToGetData["Zone"].ToString();
                    cboArea.Text = SvCls.GblRdrToGetData["Area"].ToString();
                    cboDeadNo.Text = SvCls.GblRdrToGetData["DeedNo"].ToString();
                    cboTradeLcNo.Text = SvCls.GblRdrToGetData["TradeLicence"].ToString();
                    cboNidNo.Text = SvCls.GblRdrToGetData["NIDNo"].ToString();
                    txtTotalCheque.Text = SvCls.GblRdrToGetData["ChequeAmt"].ToString();
                    cboResponsibility.Text = SvCls.GblRdrToGetData["Responsibility"].ToString();
                    cboResMobile.Text = SvCls.GblRdrToGetData["ResMob"].ToString();
                    cboSubResponsibility.Text = SvCls.GblRdrToGetData["SubRes"].ToString();
                    cboMainResponsibility.Text = SvCls.GblRdrToGetData["MainRes"].ToString();
                    cboAcctHead.Text = SvCls.GblRdrToGetData["HeadID"].ToString();
                    cboComName.Text = SvCls.GblRdrToGetData["ComName"].ToString();

                    GridHeading();
                }
                else
                {
                    ShowMessage("not found", "");
                }
            }
        }

        private void chkSMS_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSMS.Checked == true)
            {
                txtSmsNo.Enabled = true;
                txtSmsNo.Select();
            }
            else { txtSmsNo.Enabled = false; }
        }

        private void btnReport_Click(object sender, EventArgs e)
        {
            ShowMessage("info", "This is your information");
        }

        private void PanelTop_Paint_1(object sender, PaintEventArgs e)
        {

        }
        private void cboSrc_Leave(object sender, EventArgs e)
        {
            qry = "SELECT AutoNo, PartyCode as ID,PartyName as [Party Name], ProName as[Proprietor],Address,ContactPerson as [Contact Person],Class,Division,Zila,Upazila,Uneon,PGroup as[Party Group],Phone,Email,Region,Zone,Area,DeedNo as[Deed No],TradeLicence as[Trade Licence],NIDNo as[NID],ChequeAmt as[Cheque Amt],Responsibility,ResMob as[Res Mobile],SubRes as[Sub Responsibility],MainRes as[Main Responsibility],HeadID as[Account Head],ComName as[Company],PcName as[Pc Name],UserCode as [User Code] FROM PartyInfo ORDER BY PartyCode DESC";
            GridSrc.DataSource = SvCls.GblDataTable(qry);
            GridSrc.Refresh();

            lblShowTotal.Text = "Total : " + GridSrc.Rows.Count.ToString();
            GridSrc.Columns[0].Visible = false;

            ShowMessage("wait", "");
        }

        private void cboComName_TextChanged(object sender, EventArgs e)
        {
            //if (cboPartyCode.Text == "")
            //{
            //    qry = "SELECT AutoNo, PartyCode as ID,PartyName as [Party Name], ProName as[Proprietor],Address,ContactPerson as [Contact Person],Class,Division,Zila,Upazila,Uneon,PGroup as[Party Group],Phone,Email,Region,Zone,Area,DeedNo as[Deed No],TradeLicence as[Trade Licence],NIDNo as[NID],ChequeAmt as[Cheque Amt],Responsibility,ResMob as[Res Mobile],SubRes as[Sub Responsibility],MainRes as[Main Responsibility],HeadID as[Account Head],ComName as[Company],PcName as[Pc Name],UserCode as [User Code] FROM PartyInfo where ComName= '" + cboComName.Text.Trim() + "' ORDER BY PartyCode asc";
            //    Grid.DataSource = SvCls.GblDataTable(qry);
            //    Grid.Refresh();

            //    lblShowTotal.Text = "Total : " + Grid.Rows.Count.ToString();
            //    Grid.Columns[0].Visible = false;
            //}            
        }

        private void cboComName_Leave(object sender, EventArgs e)
        {
            qry = "SELECT AutoNo, PartyCode as ID,PartyName as [Party Name], ProName as[Proprietor],Address,ContactPerson as [Contact Person],Class,Division,Zila,Upazila,Uneon,PGroup as[Party Group],Phone,Email,Region,Zone,Area,DeedNo as[Deed No],TradeLicence as[Trade Licence],NIDNo as[NID],ChequeAmt as[Cheque Amt],Responsibility,ResMob as[Res Mobile],SubRes as[Sub Responsibility],MainRes as[Main Responsibility],HeadID as[Account Head],ComName as[Company] FROM PartyInfo where ComName= '" + cboComName.Text.Trim() + "' ORDER BY PartyCode asc";
            Grid.DataSource = SvCls.GblDataTable(qry);
            Grid.Refresh();

            lblShowTotal.Text = "Total : " + Grid.Rows.Count.ToString();
            Grid.Columns[0].Visible = false;
        }

        private void cboPartyCode_TextChanged(object sender, EventArgs e)
        {      
            
        }

        private void Grid_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            int i;
            i = Grid.SelectedCells[0].RowIndex;
            cboAutoNo.Text = Grid.Rows[i].Cells[0].Value.ToString();
           // cboComName.Text = Grid.Rows[i].Cells[1].Value.ToString();
            cboPartyCode.Text = Grid.Rows[i].Cells[1].Value.ToString();
            cboPartyName.Text = Grid.Rows[i].Cells[2].Value.ToString();

            cboProName.Text = Grid.Rows[i].Cells[3].Value.ToString();
            cboAddress.Text = Grid.Rows[i].Cells[4].Value.ToString();
            cboConPerson.Text = Grid.Rows[i].Cells[5].Value.ToString();
            cboClass.Text = Grid.Rows[i].Cells[6].Value.ToString();

            cboDivision.Text = Grid.Rows[i].Cells[7].Value.ToString();
            cboThana.Text = Grid.Rows[i].Cells[8].Value.ToString();
            cboZilla.Text = Grid.Rows[i].Cells[9].Value.ToString();
            cboUnion.Text = Grid.Rows[i].Cells[10].Value.ToString();

            cboGroup.Text = Grid.Rows[i].Cells[11].Value.ToString();
            txtPhone.Text = Grid.Rows[i].Cells[12].Value.ToString();
            txtEmail.Text = Grid.Rows[i].Cells[13].Value.ToString();
            cboRegion.Text = Grid.Rows[i].Cells[14].Value.ToString();

            cboZone.Text = Grid.Rows[i].Cells[15].Value.ToString();
            cboArea.Text = Grid.Rows[i].Cells[16].Value.ToString();
            cboDeadNo.Text = Grid.Rows[i].Cells[17].Value.ToString();
            cboTradeLcNo.Text = Grid.Rows[i].Cells[18].Value.ToString();
            cboNidNo.Text = Grid.Rows[i].Cells[19].Value.ToString();
            txtTotalCheque.Text = Grid.Rows[i].Cells[20].Value.ToString();

            cboResponsibility.Text = Grid.Rows[i].Cells[21].Value.ToString();
            cboResMobile.Text = Grid.Rows[i].Cells[22].Value.ToString();
            cboSubResponsibility.Text = Grid.Rows[i].Cells[23].Value.ToString();
            cboMainResponsibility.Text = Grid.Rows[i].Cells[24].Value.ToString();
            cboAcctHead.Text = Grid.Rows[i].Cells[25].Value.ToString();
            cboComName.Text = Grid.Rows[i].Cells[26].Value.ToString();
           //cboRegion.Text = Grid.Rows[i].Cells[27].Value.ToString();
        }

        private void cboComName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboPartyCode.Select();
            }
        }

        private void cboPartyCode_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboPartyName.Select();
            }
        }

        private void cboPartyName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboProName.Select();
            }
        }

        private void cboProName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboAddress.Select();
            }
        }

        private void cboAddress_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboConPerson.Select();
            }
        }

        private void cboConPerson_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                txtPhone.Select();
            }
        }

        private void txtPhone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboDivision.Select();
            }
        }

        private void cboDivision_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboThana.Select();
            }
        }

        private void cboThana_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboGroup.Select();
            }
        }

        private void cboGroup_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                txtEmail.Select();
            }
        }

        private void txtEmail_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboZilla.Select();
            }
        }

        private void cboZilla_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboUnion.Select();
            }
        }

        private void cboUnion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboClass.Select();
            }
        }

        private void cboClass_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboZone.Select();
            }
        }

        private void cboZone_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboDeadNo.Select();
            }
        }

        private void cboDeadNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboNidNo.Select();
            }
        }

        private void cboNidNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                txtTotalCheque.Select();
            }
        }

        private void txtTotalCheque_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboRegion.Select();
            }
        }

        private void cboRegion_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboArea.Select();
            }
        }

        private void cboArea_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboTradeLcNo.Select();
            }
        }

        private void cboTradeLcNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                chkSMS.Select();
            }
        }

        private void txtSmsNo_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboAcctHead.Select();
            }
        }

        private void cboAcctHead_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboResponsibility.Select();
            }
        }

        private void cboResponsibility_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboResMobile.Select();
            }
        }

        private void cboResMobile_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboSubResponsibility.Select();
            }
        }

        private void cboSubResponsibility_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboMainResponsibility.Select();
            }
        }

        private void cboMainResponsibility_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                btnSave.Select();
            }
        }

        private void btnSave_KeyUp(object sender, KeyEventArgs e)
        {
            //if (e.KeyChar.ToString() == "\r")
            //{
            //    txtMojudAmt.Select();
            //}
        }

        private void btnSave_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                btnAddNew.Select();
            }
        }
    }
}