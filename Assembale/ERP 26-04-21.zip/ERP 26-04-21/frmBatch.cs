﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ERP
{
    public partial class frmBatch : Form
    {

        ClsMain SvCls = new ClsMain();
        ClsVar ClsVar = new ClsVar();
        string Qry;
        string checkqry;
        string EdtQry;
        string comID = "";
        public frmBatch()
        {
            InitializeComponent();
        }

        private void btnAddNew_Click(object sender, EventArgs e)
        {
            SvCls.toGetData("select isnull(max(convert(numeric,BatchID)),0)+1 as BatchID from BatchInfo where ISNUMERIC(BatchID) = 1");

            if (SvCls.GblRdrToGetData.Read())
            {
                cboBatchID.Text = SvCls.GblRdrToGetData["BatchID"].ToString();
                SvCls.GblCon.Close();
            }

            txtChks.Text = "";
            cboChksType.Text = "";
            cboBName.Text = "";
            cboBLoc.Text = "";
            cboSLNo.Text = "";
            txtRmk.Text = "";
            txtChks.Text = "";
            cboBatchID.Focus();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            cboComName.Text = "";
            cboBatchID.Text = "";
            cboChksType.Text = "";
            cboBName.Text = "";
            cboBLoc.Text = "";
            cboSLNo.Text = "";
            txtRmk.Text = "";
            txtChks.Text = "";
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void cboComName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                btnAddNew.Select();
            }
        }

        private void cboBatchID_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                txtChks.Select();
            }
        }

        private void txtChks_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboChksType.Select();
            }
        }

        private void cboChksType_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboBLoc.Select();
            }
        }

        private void cboBLoc_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                cboBName.Select();
            }
        }

        private void cboBName_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                txtRmk.Select();
            }
        }



        private void txtRmk_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar.ToString() == "\r")
            {
                btnSave.Select();
            }
        }

        private void ShowMessage(string type, string msg)
        {
            if (type == "info")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblDelIco.Visible = false;
                lblWaitIco.Visible = false;
                lblMsgIco.Visible = false;
                lblInfoIco.Visible = true;
                lblMsg.Text = msg;
                this.PanelTop.BackColor = Color.DarkBlue;
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "save")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblDelIco.Visible = false;
                lblInfoIco.Visible = false;
                lblWaitIco.Visible = false;
                lblMsgIco.Visible = true;
                lblMsg.Text = "Save Successfully....!";
                this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(168)))), ((int)(((byte)(73)))));
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "update")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblDelIco.Visible = false;
                lblInfoIco.Visible = false;
                lblWaitIco.Visible = false;
                lblMsgIco.Visible = true;
                lblMsg.Text = "Edit Successfully....!";
                this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(55)))), ((int)(((byte)(168)))), ((int)(((byte)(73)))));
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "delete")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblInfoIco.Visible = false;
                lblMsgIco.Visible = false;
                lblWaitIco.Visible = false;
                lblDelIco.Visible = true;
                lblMsg.Text = "Delete Successfully....!";
                this.PanelTop.BackColor = Color.OrangeRed;
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "wait")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblSadIco.Visible = false;
                lblInfoIco.Visible = false;
                lblDelIco.Visible = false;
                lblMsgIco.Visible = false;
                lblWaitIco.Visible = true;
                lblMsg.Text = "Please wait, Loading...!";
                this.PanelTop.BackColor = Color.DarkOrange;
                lblMsg.ForeColor = Color.White;
            }
            else if (type == "not found")
            {
                MsgTimer.Stop();
                MsgTimer.Start();
                lblInfoIco.Visible = false;
                lblMsgIco.Visible = false;
                lblDelIco.Visible = false;
                lblWaitIco.Visible = false;
                lblSadIco.Visible = true;
                lblMsg.Text = "Sorry..! No Record Found";
                this.PanelTop.BackColor = Color.OrangeRed;
                lblMsg.ForeColor = Color.White;
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {

            if (cboComName.Text.Trim() == "")
            {
                MessageBox.Show("Company Name  Can't Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                cboComName.Select();
                return;
            }

            if (cboBatchID.Text.Trim() == "")
            {
                MessageBox.Show("Batch ID  Can't Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                cboBatchID.Select();
                return;
            }

            if (cboChksType.Text.Trim() == "")
            {
                MessageBox.Show("Chks Type  Can't Blank", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                cboChksType.Select();
                return;
            }

            if (txtChks.Text.Trim() == "")
            {
                txtChks.Text = "0";
            }

            SvCls.toGetData("select comID from Company where ComName = '"+cboComName.Text.Trim()+"'");
            if (SvCls.GblRdrToGetData.Read())
            {
                comID = Convert.ToString(SvCls.GblRdrToGetData["comID"]);
                Qry = "insert BatchInfo(ComId,BatchId,TotalChks,ChksType,BreedName,BLoc,rmk,sl,PcName,UserCode) values('" + comID.ToString().Trim() + "','" + cboBatchID.Text.Trim() + "'," + txtChks.Text.Trim() + ",'" + cboChksType.Text.Trim() + "','" + cboBName.Text.Trim() + "','" + cboBLoc.Text.Trim() + "','" + txtRmk.Text.Trim() + "',0,'" + ClsVar.GblPcName + "','" + ClsVar.GblUserId + "')";
                checkqry = "select ComId,TotalChks,ChksType,BreedName,BLoc,rmk,sl,PcName,UserCode from BatchInfo where BatchId = '" + cboBatchID.Text.Trim() + "'";
                EdtQry = "update BatchInfo set ComId = '" + comID + "', TotalChks = " + txtChks.Text.Trim() + ", ChksType = '" + cboChksType.Text.Trim() + "', BreedName = '" + cboBName.Text.Trim() + "',BLoc = '" + cboBLoc.Text.Trim() + "',rmk = '" + txtRmk.Text.Trim() + "', sl = 0, PcName = '" + ClsVar.GblPcName + "',UserCode = '" + ClsVar.GblUserId + "' where BatchId = '" + cboBatchID.Text.Trim() + "'";

                SvCls.toGetData(checkqry);
                if (SvCls.GblRdrToGetData.Read())
                {
                    SvCls.insertUpdate(EdtQry);
                    //Message
                    ShowMessage("update", "");
                }
                else
                {
                    SvCls.insertUpdate(Qry);
                    //Message
                    ShowMessage("save", "");

                }
                btnLoadGridData_Click(null, null);
               // btnLoadCombo_Click(null, null);
                cboComName.Focus();
            }

            else
            {
                MessageBox.Show("Invalid Company Name!!!\n Please, select Valid Company Name ", "Powerpoint Technologies", MessageBoxButtons.OK, MessageBoxIcon.Warning);

                cboComName.Select();
                return;
            }


           
        }

        private void MsgTimer_Tick(object sender, EventArgs e)
        {
            this.PanelTop.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            lblMsg.Text = "Notification...";
            lblMsgIco.Visible = false;
            lblSadIco.Visible = false;
            lblDelIco.Visible = false;
            lblWaitIco.Visible = false;
            lblInfoIco.Visible = true;

            MsgTimer.Enabled = false;
        }

        private void btnLoadCombo_Click(object sender, EventArgs e)
        {
            Qry = "select distinct ComName from Company";
            cboComName.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboComName.DisplayMember = "ComName";
            cboComName.Text = "";

            Qry = "select distinct BatchId from BatchInfo";
            cboBatchID.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboBatchID.DisplayMember = "BatchId";
            cboBatchID.Text = "";

            Qry = "select distinct BLoc from BatchInfo where BLoc != ''";
            cboBLoc.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboBLoc.DisplayMember = "BLoc";
            cboBLoc.Text = "";

            Qry = "select distinct ChksType from BatchInfo  where ChksType != ''";
            cboChksType.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboChksType.DisplayMember = "ChksType";
            cboChksType.Text = "";

            Qry = "select distinct BreedName from BatchInfo where BreedName != ''";
            cboBName.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboBName.DisplayMember = "BreedName";
            cboBName.Text = "";

            Qry = "select distinct SL from BatchInfo";
            cboSLNo.DataSource = SvCls.GblDataSet(Qry).Tables[0];
            cboSLNo.DisplayMember = "SL";
            cboSLNo.Text = "";



        }

        private void Grid_Head()
        {
            Grid.DataSource = SvCls.GblDataTable("select ComName as 'Company Name', BatchId as 'Batch Id', cast(TotalChks as decimal(10,2)) as 'Total Chks', ChksType as 'Chks Type', BreedName as 'Breed Name', BLoc as 'Breed Location',rmk as 'Remarks' from BatchInfo as b, Company as c where c.ComId = b.ComId");
            Grid.Refresh();
            lblShowTotal_TextChanged(null, null);
        }

        private void lblShowTotal_TextChanged(object sender, EventArgs e)
        {
            Qry = "select count(BatchId) as BatchId from BatchInfo";
            SvCls.toGetData(Qry);
            string lblMsg = "Total Record: ";

            if (SvCls.GblRdrToGetData.Read())
            {

                lblShowTotal.Text = lblMsg + SvCls.GblRdrToGetData["BatchId"].ToString();
            }
        }

        private void btnLoadGridData_Click(object sender, EventArgs e)
        {
            Grid_Head();
            lblShowTotal_TextChanged(null, null);
        }

        private void frmBatch_Load(object sender, EventArgs e)
        {
            btnLoadGridData_Click(null, null);
            btnLoadCombo_Click(null, null);
            cboComName.Select();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (cboBatchID.Text.Trim() == "")
            {
                MessageBox.Show("Please, Enter Valid Compnay ID...!!", "Message", MessageBoxButtons.OK, MessageBoxIcon.Information);
                cboBatchID.Select();
                return;
            }
            checkqry = "select * from BatchInfo where BatchID = '" + cboBatchID.Text.Trim() + "'";
            Qry = "delete from BatchInfo where BatchID = '" + cboBatchID.Text.Trim() + "'";
            if (MessageBox.Show("Do you realy want to delete ?", "Powerpoint Technologies.", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) == DialogResult.Yes)
            {

                SvCls.toGetData(checkqry);
                if (SvCls.GblRdrToGetData.Read())
                {
                    SvCls.insertUpdate(Qry);
                    //Message
                    ShowMessage("delete", "");
                }

                else
                {
                    ShowMessage("not found", "");
                }

                btnAddNew.Select();
                btnLoadGridData_Click(null, null);
               // btnLoadCombo_Click(null, null);

            }
        }

        private void cboBatchID_Leave(object sender, EventArgs e)
        {
            if (cboBatchID.Text.Trim() != "")
            {

                Qry = "select ComName,TotalChks,ChksType,BreedName,BLoc,rmk,sl from Company as c,BatchInfo as b where c.comid = b.comid and BatchId = '"+cboBatchID.Text.Trim()+"'";
                SvCls.toGetData(Qry);
                if (SvCls.GblRdrToGetData.Read())
                {
                    cboComName.Text = SvCls.GblRdrToGetData["ComName"].ToString();
                    cboBLoc.Text = SvCls.GblRdrToGetData["BLoc"].ToString();
                    txtChks.Text = SvCls.GblRdrToGetData["TotalChks"].ToString();
                    cboChksType.Text = SvCls.GblRdrToGetData["ChksType"].ToString();
                    cboBName.Text = SvCls.GblRdrToGetData["BreedName"].ToString();
                    txtRmk.Text = SvCls.GblRdrToGetData["rmk"].ToString();
                    cboSLNo.Text = SvCls.GblRdrToGetData["sl"].ToString();
                    cboComName.Focus();
                }
                else
                {
                    ShowMessage("not found", "");

                    cboBLoc.Text = "";
                    cboBName.Text = "";
                    cboChksType.Text = "";
                    txtRmk.Text = "";
                    txtChks.Text = "";
                    cboSLNo.Text = "";
                    txtChks.Select();

                }

            }
        }

        private void Grid_DoubleClick(object sender, EventArgs e)
        {
            int i;
            i = Grid.SelectedCells[0].RowIndex;
            cboComName.Text = Grid.Rows[i].Cells[0].Value.ToString();
            cboBatchID.Text = Grid.Rows[i].Cells[1].Value.ToString();
            txtChks.Text = Grid.Rows[i].Cells[2].Value.ToString();
            cboChksType.Text = Grid.Rows[i].Cells[3].Value.ToString();
            cboBLoc.Text = Grid.Rows[i].Cells[4].Value.ToString();
            cboBName.Text = Grid.Rows[i].Cells[5].Value.ToString();
            txtRmk.Text = Grid.Rows[i].Cells[6].Value.ToString();
            cboComName.Focus();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            this.grpSrc.Size = new System.Drawing.Size(1089, 608);
            this.grpSrc.Location = new System.Drawing.Point(5, 33);
            grpSrc.Visible = true;
        }

        private void btnCloseSrc_Click(object sender, EventArgs e)
        {
            grpSrc.Visible = false;
        }
    }
}
