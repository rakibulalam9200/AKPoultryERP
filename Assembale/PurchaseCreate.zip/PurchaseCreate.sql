USE [AKPOULTRY_ERP]
GO

/****** Object:  Table [dbo].[Purchase]    Script Date: 15/06/2021 11:49:10 AM ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

SET ANSI_PADDING ON
GO

CREATE TABLE [dbo].[Purchase](
	[ComId] [varchar](20) NOT NULL,
	[AutoNo] [int] IDENTITY(1,1) NOT NULL,
	[AutoNoFormMstrTbl] [int] NOT NULL,
	[PartyAutoNo] [int] NOT NULL,
	[LocID] [varchar](20) NOT NULL,
	[LocAutoNo] [int] NOT NULL,
	[SlNo] [int] NOT NULL,
	[ItemCode] [varchar](50) NOT NULL,
	[ItemAutoNo] [numeric](18, 0) NOT NULL,
	[Qty] [money] NOT NULL,
	[UnitPrice] [money] NOT NULL,
	[TotalPrice] [money] NOT NULL,
	[Rmk] [varchar](250) NOT NULL,
	[ComName] [varchar](150) NOT NULL,
	[PcName] [varchar](50) NOT NULL,
	[UserCode] [varchar](50) NOT NULL,
	[EntryTime] [datetime] NOT NULL,
	[UserIP] [varchar](100) NOT NULL,
	[PurchaseCode] [varchar](50) NOT NULL
) ON [PRIMARY]

GO

SET ANSI_PADDING OFF
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [ComId]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [AutoNoFormMstrTbl]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [PartyAutoNo]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [LocID]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [LocAutoNo]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [SlNo]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [ItemCode]
GO

ALTER TABLE [dbo].[Purchase] ADD  CONSTRAINT [DF_Purchase_ItemAutoNo]  DEFAULT ((0)) FOR [ItemAutoNo]
GO

ALTER TABLE [dbo].[Purchase] ADD  CONSTRAINT [DF_Purchase_UnitPrice]  DEFAULT ((0)) FOR [UnitPrice]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [ComName]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [PcName]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [UserCode]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT (getdate()) FOR [EntryTime]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [UserIP]
GO

ALTER TABLE [dbo].[Purchase] ADD  DEFAULT ('') FOR [PurchaseCode]
GO


