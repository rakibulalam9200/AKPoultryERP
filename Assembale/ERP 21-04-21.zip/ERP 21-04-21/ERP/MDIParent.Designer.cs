﻿namespace ERP
{
    partial class MDIParent
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MDIParent));
            this.menuStrip = new System.Windows.Forms.MenuStrip();
            this.masterInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.form1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.partyCreditInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.createBankACToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.itemInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.batchInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.accountsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.voucherEntryToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.chartOfAccountToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.hRMToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.employeeInfoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.companyInformationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip
            // 
            this.menuStrip.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.menuStrip.Font = new System.Drawing.Font("Calibri", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.menuStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.masterInformationToolStripMenuItem,
            this.accountsToolStripMenuItem,
            this.hRMToolStripMenuItem});
            this.menuStrip.Location = new System.Drawing.Point(0, 0);
            this.menuStrip.Name = "menuStrip";
            this.menuStrip.RenderMode = System.Windows.Forms.ToolStripRenderMode.Professional;
            this.menuStrip.Size = new System.Drawing.Size(997, 24);
            this.menuStrip.TabIndex = 0;
            this.menuStrip.Text = "MenuStrip";
            // 
            // masterInformationToolStripMenuItem
            // 
            this.masterInformationToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.form1ToolStripMenuItem,
            this.partyCreditInformationToolStripMenuItem,
            this.createBankACToolStripMenuItem,
            this.itemInformationToolStripMenuItem,
            this.batchInformationToolStripMenuItem,
            this.companyInformationToolStripMenuItem});
            this.masterInformationToolStripMenuItem.Name = "masterInformationToolStripMenuItem";
            this.masterInformationToolStripMenuItem.Size = new System.Drawing.Size(126, 20);
            this.masterInformationToolStripMenuItem.Text = "Master Information";
            this.masterInformationToolStripMenuItem.Click += new System.EventHandler(this.masterInformationToolStripMenuItem_Click);
            // 
            // form1ToolStripMenuItem
            // 
            this.form1ToolStripMenuItem.Name = "form1ToolStripMenuItem";
            this.form1ToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.form1ToolStripMenuItem.Text = "Party Information";
            this.form1ToolStripMenuItem.Click += new System.EventHandler(this.form1ToolStripMenuItem_Click);
            // 
            // partyCreditInformationToolStripMenuItem
            // 
            this.partyCreditInformationToolStripMenuItem.Name = "partyCreditInformationToolStripMenuItem";
            this.partyCreditInformationToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.partyCreditInformationToolStripMenuItem.Text = "Party Credit Information";
            this.partyCreditInformationToolStripMenuItem.Click += new System.EventHandler(this.partyCreditInformationToolStripMenuItem_Click);
            // 
            // createBankACToolStripMenuItem
            // 
            this.createBankACToolStripMenuItem.Name = "createBankACToolStripMenuItem";
            this.createBankACToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.createBankACToolStripMenuItem.Text = "Create Bank AC";
            this.createBankACToolStripMenuItem.Click += new System.EventHandler(this.createBankACToolStripMenuItem_Click);
            // 
            // itemInformationToolStripMenuItem
            // 
            this.itemInformationToolStripMenuItem.Name = "itemInformationToolStripMenuItem";
            this.itemInformationToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.itemInformationToolStripMenuItem.Text = "Item Information";
            this.itemInformationToolStripMenuItem.Click += new System.EventHandler(this.itemInformationToolStripMenuItem_Click);
            // 
            // batchInformationToolStripMenuItem
            // 
            this.batchInformationToolStripMenuItem.Name = "batchInformationToolStripMenuItem";
            this.batchInformationToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.batchInformationToolStripMenuItem.Text = "Batch Information";
            // 
            // accountsToolStripMenuItem
            // 
            this.accountsToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.voucherEntryToolStripMenuItem,
            this.chartOfAccountToolStripMenuItem});
            this.accountsToolStripMenuItem.Name = "accountsToolStripMenuItem";
            this.accountsToolStripMenuItem.Size = new System.Drawing.Size(68, 20);
            this.accountsToolStripMenuItem.Text = "Accounts";
            // 
            // voucherEntryToolStripMenuItem
            // 
            this.voucherEntryToolStripMenuItem.Name = "voucherEntryToolStripMenuItem";
            this.voucherEntryToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.voucherEntryToolStripMenuItem.Text = "Voucher Entry";
            this.voucherEntryToolStripMenuItem.Click += new System.EventHandler(this.voucherEntryToolStripMenuItem_Click);
            // 
            // chartOfAccountToolStripMenuItem
            // 
            this.chartOfAccountToolStripMenuItem.Name = "chartOfAccountToolStripMenuItem";
            this.chartOfAccountToolStripMenuItem.Size = new System.Drawing.Size(167, 22);
            this.chartOfAccountToolStripMenuItem.Text = "Chart Of Account";
            // 
            // hRMToolStripMenuItem
            // 
            this.hRMToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.employeeInfoToolStripMenuItem});
            this.hRMToolStripMenuItem.Name = "hRMToolStripMenuItem";
            this.hRMToolStripMenuItem.Size = new System.Drawing.Size(45, 20);
            this.hRMToolStripMenuItem.Text = "HRM";
            // 
            // employeeInfoToolStripMenuItem
            // 
            this.employeeInfoToolStripMenuItem.Name = "employeeInfoToolStripMenuItem";
            this.employeeInfoToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.employeeInfoToolStripMenuItem.Text = "Employee Info";
            this.employeeInfoToolStripMenuItem.Click += new System.EventHandler(this.employeeInfoToolStripMenuItem_Click);
            // 
            // companyInformationToolStripMenuItem
            // 
            this.companyInformationToolStripMenuItem.Name = "companyInformationToolStripMenuItem";
            this.companyInformationToolStripMenuItem.Size = new System.Drawing.Size(208, 22);
            this.companyInformationToolStripMenuItem.Text = "Company Information";
            this.companyInformationToolStripMenuItem.Click += new System.EventHandler(this.companyInformationToolStripMenuItem_Click);
            // 
            // MDIParent
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.ClientSize = new System.Drawing.Size(997, 575);
            this.Controls.Add(this.menuStrip);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip;
            this.Name = "MDIParent";
            this.Text = "Poultry ERP - AK Poultry && Hatchery Limited. - Developed By: Powerpoint Technolo" +
    "gies";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.MDIParent_Load);
            this.menuStrip.ResumeLayout(false);
            this.menuStrip.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }
        #endregion


        private System.Windows.Forms.MenuStrip menuStrip;
        private System.Windows.Forms.ToolTip toolTip;
        private System.Windows.Forms.ToolStripMenuItem masterInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem form1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem partyCreditInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem createBankACToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem accountsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem voucherEntryToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem chartOfAccountToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem itemInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem batchInformationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem hRMToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem employeeInfoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem companyInformationToolStripMenuItem;
    }
}



