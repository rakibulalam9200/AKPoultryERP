﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ERP
{
    
    public partial class MDIParent : Form
    {
        private int childFormNumber = 0;

        public MDIParent()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
            
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void SetDateFormat()
        {
            //using Microsoft.Win32;
            //Get Data From Text Boxes


            string DateFormat = "dd/MM/yyyy";

            //string TimeFormat = txtTimeFormat.Text.Trim();

            //string Currency = txtCurrency.Text.Trim();



            //Registry Logic

            //Open Sub key

            RegistryKey rkey = Registry.CurrentUser.OpenSubKey(@"Control Panel\International", true);

            ///Set Values

            //rkey.SetValue("sTimeFormat", TimeFormat);

            rkey.SetValue("sShortDate", DateFormat);

            //rkey.SetValue("sCurrency", Currency);

            //Close the Registry

            rkey.Close();


        }

        private void MDIParent_Load(object sender, EventArgs e)
        {
            SetDateFormat();

            StreamReader sr = new StreamReader(Application.StartupPath + "\\check.sys");
            ClsVar.ServerName = sr.ReadLine();
            ClsVar.DataBaseName = sr.ReadLine();
            ClsVar.SqlPassword = sr.ReadLine();
            ClsVar.SqlUId = sr.ReadLine();
            ClsVar.gblPwdFroShow = sr.ReadLine();
            ClsVar.directPrint = sr.ReadLine();
            sr.Close();

            ClsMain SvCls = new ClsMain();

            SvCls.toGetData("select host_name() as pcName");
            if (SvCls.GblRdrToGetData.Read())
            {
                ClsVar.GblPcName = SvCls.GblRdrToGetData["pcName"].ToString();
                
                
            }


        }


        private void form1ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PartyInfo frm = new PartyInfo();
            frm.MdiParent = this;
            frm.Show();
        }

        private void partyCreditInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            PartyCreditInfo frm = new PartyCreditInfo();
            frm.MdiParent = this;
            frm.Show();
        }

        private void createBankACToolStripMenuItem_Click(object sender, EventArgs e)
        {
            CreateBankAc frm = new CreateBankAc();
            frm.MdiParent = this;
            frm.Show();
        }

        private void voucherEntryToolStripMenuItem_Click(object sender, EventArgs e)
        {
            VoucherEntry frm = new VoucherEntry();
            frm.MdiParent = this;
            frm.Show();
        }

        private void itemInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void employeeInfoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Employee frm = new Employee();
            frm.MdiParent = this;
            frm.Show();
        }

        private void masterInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void companyInformationToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmCompany frm = new frmCompany();
            frm.MdiParent = this;
            frm.Show();
        }
    }
}
